using Microsoft.AspNetCore.Mvc;
using ProxySignedUrlApi.Models;
using ProxySignedUrlApi.Services;

namespace ProxySignedUrlApi.Controllers;

[ApiController]
[Route("proxy/signed-url")]
public class ProxySignedUrlController : ControllerBase
{
    private readonly SigningApiClient _signingApi;

    public ProxySignedUrlController(SigningApiClient signingApi)
    {
        _signingApi = signingApi;
    }

    /// <summary>
    /// Recebe BucketName e ObjectName/ObjetName, chama a API real de assinatura e devolve a mesma resposta.
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<SignedUrlResponse>> Create([FromBody] SignedUrlRequest req, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(req.BucketName))
            return BadRequest("BucketName é obrigatório.");
        if (string.IsNullOrWhiteSpace(req.ObjectName))
            return BadRequest("ObjectName/ObjetName é obrigatório.");

        var signed = await _signingApi.GetSignedUploadUrlAsync(req, ct);
        return Ok(signed);
    }
}
