using Microsoft.AspNetCore.Mvc;
using ProxySignedUrlApi.Services;

namespace ProxySignedUrlApi.Controllers;

[ApiController]
[Route("gcs/upload")]
public class GcsUploadController : ControllerBase
{
    private readonly GcsStorageService _storage;

    public GcsUploadController(GcsStorageService storage)
    {
        _storage = storage;
    }

    /// <summary>
    /// Faz upload direto para o GCS via IFormFile (multipart/form-data).
    /// </summary>
    /// <param name="bucket">Nome do bucket</param>
    /// <param name="objectName">Caminho do objeto no bucket (ex: upload/asdasdas.jpg)</param>
    /// <param name="file">Arquivo enviado no corpo (campo "file")</param>
    [HttpPost]
    [RequestSizeLimit(long.MaxValue)]
    [RequestFormLimits(MultipartBodyLengthLimit = long.MaxValue)]
    public async Task<IActionResult> Upload([FromQuery] string bucket, [FromQuery] string objectName, IFormFile file, CancellationToken ct)
    {
        if (file is null || file.Length == 0) return BadRequest("Arquivo ausente.");
        var contentType = string.IsNullOrWhiteSpace(file.ContentType) ? "application/octet-stream" : file.ContentType;

        await using var stream = file.OpenReadStream();
        await _storage.UploadAsync(bucket, objectName, contentType, stream, ct);

        return Ok(new { Bucket = bucket, ObjectName = objectName, Size = file.Length, ContentType = contentType });
    }
}
