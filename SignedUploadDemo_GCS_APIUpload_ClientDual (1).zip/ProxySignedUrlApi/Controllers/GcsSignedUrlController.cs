using Microsoft.AspNetCore.Mvc;
using ProxySignedUrlApi.Models;
using ProxySignedUrlApi.Services;

namespace ProxySignedUrlApi.Controllers;

[ApiController]
[Route("gcs/signed-upload-url")]
public class GcsSignedUrlController : ControllerBase
{
    private readonly GcsSignedUrlService _gcs;

    public GcsSignedUrlController(GcsSignedUrlService gcs)
    {
        _gcs = gcs;
    }

    /// <summary>
    /// Gera URL assinada V4 de upload (PUT) diretamente no GCS.
    /// </summary>
    [HttpPost]
    public ActionResult<SignedUrlResponse> Create([FromBody] SignedUrlRequest req, [FromQuery] int expiresSeconds = 3600)
    {
        if (string.IsNullOrWhiteSpace(req.BucketName))
            return BadRequest("BucketName é obrigatório.");
        if (string.IsNullOrWhiteSpace(req.ObjectName))
            return BadRequest("ObjectName/ObjetName é obrigatório.");

        var (url, headers) = _gcs.CreateV4UploadUrl(
            bucket: req.BucketName,
            objectName: req.ObjectName,
            duration: TimeSpan.FromSeconds(Math.Clamp(expiresSeconds, 60, 7 * 24 * 3600)),
            contentType: string.IsNullOrWhiteSpace(req.ContentType) ? "application/octet-stream" : req.ContentType,
            extraHeaders: null
        );

        return Ok(new SignedUrlResponse
        {
            Url = url,
            Method = "PUT",
            ExpiresAt = DateTimeOffset.UtcNow.AddSeconds(Math.Clamp(expiresSeconds, 60, 7 * 24 * 3600)),
            RequiredHeaders = headers
        });
    }
}
