using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using Microsoft.Extensions.Logging;

namespace ProxySignedUrlApi.Services;

public sealed class GcsStorageService
{
    private readonly ILogger<GcsStorageService> _logger;
    private readonly StorageClient _storage;

    public GcsStorageService(ILogger<GcsStorageService> logger)
    {
        _logger = logger;
        _storage = CreateStorageClient();
    }

    private StorageClient CreateStorageClient()
    {
        try
        {
            var saPath = Environment.GetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS");
            if (!string.IsNullOrWhiteSpace(saPath) && File.Exists(saPath))
            {
                _logger.LogInformation("Creating StorageClient from service account key file at {Path}", saPath);
                var cred = GoogleCredential.FromFile(saPath);
                return StorageClient.Create(cred);
            }

            _logger.LogInformation("Creating StorageClient from Application Default Credentials (ADC)");
            var adc = GoogleCredential.GetApplicationDefault();
            return StorageClient.Create(adc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create StorageClient.");
            throw;
        }
    }

    public async Task UploadAsync(string bucket, string objectName, string contentType, Stream data, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(bucket)) throw new ArgumentException("bucket required", nameof(bucket));
        if (string.IsNullOrWhiteSpace(objectName)) throw new ArgumentException("objectName required", nameof(objectName));
        if (data is null) throw new ArgumentNullException(nameof(data));
        if (string.IsNullOrWhiteSpace(contentType)) contentType = "application/octet-stream";

        var options = new UploadObjectOptions
        {
            ChunkSize = 8 * 1024 * 1024 // 8 MB chunks, adjust as needed
        };

        await _storage.UploadObjectAsync(
            bucket: bucket,
            objectName: objectName,
            contentType: contentType,
            source: data,
            options: options,
            cancellationToken: ct);
    }
}
