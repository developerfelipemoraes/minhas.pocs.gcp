using System.Net.Http.Json;
using Microsoft.Extensions.Options;
using ProxySignedUrlApi.Models;

namespace ProxySignedUrlApi.Services;

public sealed class SigningApiOptions
{
    public const string SectionName = "SigningApi";
    public string BaseUrl { get; set; } = string.Empty;         // ex.: https://signer.yourdomain.com
    public string EndpointPath { get; set; } = "/api/signed-upload-url"; // caminho do endpoint remoto
    public string? ApiKey { get; set; } // se precisar autenticar
}

public sealed class SigningApiClient
{
    private readonly HttpClient _http;
    private readonly SigningApiOptions _opt;

    public SigningApiClient(HttpClient http, IOptions<SigningApiOptions> opt)
    {
        _http = http;
        _opt = opt.Value;
        if (!string.IsNullOrWhiteSpace(_opt.BaseUrl))
            _http.BaseAddress = new Uri(_opt.BaseUrl);
    }

    public async Task<SignedUrlResponse> GetSignedUploadUrlAsync(SignedUrlRequest req, CancellationToken ct)
    {
        using var message = new HttpRequestMessage(HttpMethod.Post, _opt.EndpointPath)
        {
            Content = JsonContent.Create(req)
        };

        if (!string.IsNullOrEmpty(_opt.ApiKey))
            message.Headers.Add("x-api-key", _opt.ApiKey);

        using var resp = await _http.SendAsync(message, ct);
        resp.EnsureSuccessStatusCode();
        var payload = await resp.Content.ReadFromJsonAsync<SignedUrlResponse>(cancellationToken: ct)
                      ?? throw new InvalidOperationException("Resposta de URL assinada inválida");
        return payload;
    }
}
