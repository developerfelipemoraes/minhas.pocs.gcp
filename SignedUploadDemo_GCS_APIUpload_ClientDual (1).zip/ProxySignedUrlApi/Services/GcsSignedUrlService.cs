using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using Microsoft.Extensions.Logging;

namespace ProxySignedUrlApi.Services;

public sealed class GcsSignedUrlService
{
    private readonly ILogger<GcsSignedUrlService> _logger;
    private UrlSigner _signer;

    public GcsSignedUrlService(ILogger<GcsSignedUrlService> logger)
    {
        _logger = logger;
        _signer = CreateSigner();
    }

    private UrlSigner CreateSigner()
    {
        // Prefer keyless via ADC if possible; falls back to service account JSON if GOOGLE_APPLICATION_CREDENTIALS is set.
        try
        {
            var saPath = Environment.GetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS");
            if (!string.IsNullOrWhiteSpace(saPath) && File.Exists(saPath))
            {
                _logger.LogInformation("Creating UrlSigner from service account key file at {Path}", saPath);
                return UrlSigner.FromServiceAccountPath(saPath);
            }

            _logger.LogInformation("Creating UrlSigner from Application Default Credentials (ADC)");
            var adc = GoogleCredential.GetApplicationDefault();
            return UrlSigner.FromCredential(adc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create UrlSigner from credentials.");
            throw;
        }
    }

    public (string Url, IDictionary<string, string> RequiredHeaders) CreateV4UploadUrl(
        string bucket,
        string objectName,
        TimeSpan duration,
        string? contentType = null,
        IDictionary<string, string>? extraHeaders = null)
    {
        if (string.IsNullOrWhiteSpace(bucket)) throw new ArgumentException("bucket required", nameof(bucket));
        if (string.IsNullOrWhiteSpace(objectName)) throw new ArgumentException("objectName required", nameof(objectName));

        var options = UrlSigner.Options.FromDuration(duration).WithHttpMethod(HttpMethod.Put);

        var headers = new Dictionary<string, IEnumerable<string>>(StringComparer.OrdinalIgnoreCase);
        var requiredHeaders = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        if (!string.IsNullOrWhiteSpace(contentType))
        {
            headers["Content-Type"] = new[] { contentType! };
            requiredHeaders["Content-Type"] = contentType!;
        }

        if (extraHeaders is not null)
        {
            foreach (var kv in extraHeaders)
            {
                headers[kv.Key] = new[] { kv.Value };
                requiredHeaders[kv.Key] = kv.Value;
            }
        }

        if (headers.Count > 0)
        {
            options = options.WithHeaders(headers);
        }

        var url = _signer.Sign(bucket, objectName, options);
        return (url, requiredHeaders);
    }
}
