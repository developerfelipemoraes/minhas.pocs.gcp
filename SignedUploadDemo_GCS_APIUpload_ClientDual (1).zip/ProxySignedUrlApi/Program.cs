using System.Text.Json.Serialization;
using ProxySignedUrlApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Configurações fortemente tipadas
builder.Services.Configure<SigningApiOptions>(
    builder.Configuration.GetSection(SigningApiOptions.SectionName));

builder.Services.AddHttpClient<SigningApiClient>();
builder.Services.AddSingleton<GcsSignedUrlService>();
builder.Services.AddSingleton<GcsStorageService>();

builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        o.JsonSerializerOptions.PropertyNamingPolicy = null; // preserva BucketName/ObjectName
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();
