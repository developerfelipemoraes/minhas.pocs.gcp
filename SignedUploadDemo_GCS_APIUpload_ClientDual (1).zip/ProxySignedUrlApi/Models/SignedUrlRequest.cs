using System.Text.Json.Serialization;

namespace ProxySignedUrlApi.Models;

public sealed class SignedUrlRequest
{
    public string BucketName { get; set; } = string.Empty;

    // Campo "oficial"
    public string? ObjectName { get; set; }

    // Alias para aceitar a grafia pedida: "ObjetName"
    [JsonPropertyName("ObjetName")]
    public string? ObjectNameAlias
    {
        get => ObjectName;
        set { if (!string.IsNullOrWhiteSpace(value)) ObjectName = value; }
    }

    // Opcional: defina explicitamente o Content-Type que será usado no PUT
    public string? ContentType { get; set; } = "image/jpeg";
}
