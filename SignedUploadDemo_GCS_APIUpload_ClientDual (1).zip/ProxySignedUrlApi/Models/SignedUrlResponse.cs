namespace ProxySignedUrlApi.Models;

public sealed class SignedUrlResponse
{
    public string Url { get; set; } = string.Empty;
    public string Method { get; set; } = "PUT"; // em geral, PUT para upload
    public DateTimeOffset ExpiresAt { get; set; }
    public IDictionary<string, string>? RequiredHeaders { get; set; } // se a API de assinatura exigir
}
