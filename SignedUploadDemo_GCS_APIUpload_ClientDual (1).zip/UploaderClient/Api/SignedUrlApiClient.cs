using System.Net.Http.Json;
using UploaderClient.Models;

namespace UploaderClient.Api;

public sealed class SignedUrlApiClient
{
    private readonly HttpClient _http;

    public SignedUrlApiClient(HttpClient http, Uri baseAddress)
    {
        _http = http;
        _http.BaseAddress = baseAddress;
        _http.Timeout = TimeSpan.FromMinutes(30);
    }

    public async Task<SignedUrlResponse> CreateSignedUploadUrlAsync(SignedUrlRequest req, CancellationToken ct)
    {
        using var resp = await _http.PostAsJsonAsync("proxy/signed-url", req, ct);
        resp.EnsureSuccessStatusCode();
        var payload = await resp.Content.ReadFromJsonAsync<SignedUrlResponse>(cancellationToken: ct)
                      ?? throw new InvalidOperationException("Resposta vazia da ProxySignedUrlApi");
        return payload;
    }

    public static async Task<HttpResponseMessage> PutFileAsync(string signedUrl, string filePath, string? contentType, CancellationToken ct)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException("Arquivo não encontrado", filePath);

        using var fs = File.OpenRead(filePath);
        using var content = new StreamContent(fs);
        if (!string.IsNullOrWhiteSpace(contentType))
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType);

        using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };

        // Importante: o verbo deve ser o mesmo usado na assinatura (geralmente PUT)
        var request = new HttpRequestMessage(HttpMethod.Put, signedUrl)
        {
            Content = content
        };

        // Se a API de assinatura exigir headers específicos, adicione-os aqui
        // ex.: request.Headers.Add("x-goog-content-sha256", "UNSIGNED-PAYLOAD");

        var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        return response;
    }
}


public static class ApiUploadHelper
{
    /// <summary>
    /// Envia o arquivo para a API (multipart/form-data) que fará o upload direto ao GCS.
    /// </summary>
    /// <param name="apiBase">ex.: http://localhost:5299/</param>
    /// <param name="bucket">ex.: filesmanager</param>
    /// <param name="objectName">ex.: upload/asdasdas.jpg</param>
    /// <param name="filePath">ex.: C:\temp\files\file0001.jpg</param>
    public static async Task<HttpResponseMessage> UploadViaApiAsync(Uri apiBase, string bucket, string objectName, string filePath, CancellationToken ct)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException("Arquivo não encontrado", filePath);

        using var http = new HttpClient { BaseAddress = apiBase, Timeout = TimeSpan.FromMinutes(30) };

        var url = $"gcs/upload?bucket={Uri.EscapeDataString(bucket)}&objectName={Uri.EscapeDataString(objectName)}";

        using var form = new MultipartFormDataContent();
        var fileName = Path.GetFileName(filePath);

        var stream = File.OpenRead(filePath);
        var fileContent = new StreamContent(stream);
        // Tente inferir content-type pelo sufixo; default será image/jpeg conforme seu caso
        var inferred = fileName.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) ? "image/jpeg" :
                       fileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ? "image/png" :
                       "application/octet-stream";
        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(inferred);

        form.Add(fileContent, "file", fileName);

        var resp = await http.PostAsync(url, form, ct);
        return resp;
    }
}
