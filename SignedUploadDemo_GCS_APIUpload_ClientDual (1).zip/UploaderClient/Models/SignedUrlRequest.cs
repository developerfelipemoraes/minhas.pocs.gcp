namespace UploaderClient.Models;

public sealed class SignedUrlRequest
{
    public string BucketName { get; set; } = string.Empty;
    public string ObjectName { get; set; } = string.Empty; // ao enviar, usaremos este
    public string? ContentType { get; set; } = "image/jpeg";
}
