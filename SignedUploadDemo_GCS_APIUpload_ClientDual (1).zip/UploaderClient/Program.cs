\
    using UploaderClient.Api;
    using UploaderClient.Models;

    // Args: --mode=signed | --mode=api | (default: run both sequentially)
    var argsList = Environment.GetCommandLineArgs().Skip(1).ToList();
    string mode = argsList.FirstOrDefault(a => a.StartsWith("--mode=", StringComparison.OrdinalIgnoreCase))?.Split('=')[1]
                  ?? (argsList.Contains("api", StringComparer.OrdinalIgnoreCase) ? "api"
                  : argsList.Contains("signed", StringComparer.OrdinalIgnoreCase) ? "signed"
                  : "both");

    // Configurações
    var proxyApiBase = new Uri("http://localhost:5299/"); // endereço local da API
    var bucket = "filesmanager";
    var objectName = "upload/asdasdas.jpg";
    var localFile = @"c:\temp\files\file0001.jpg";
    var contentType = "image/jpeg";

    var cts = new CancellationTokenSource();

    async Task RunSignedAsync()
    {
        Console.WriteLine("[SIGNED] Solicitando URL assinada...");
        var api = new SignedUrlApiClient(new HttpClient(), proxyApiBase);
        var signed = await api.CreateSignedUploadUrlAsync(new SignedUrlRequest
        {
            BucketName = bucket,
            ObjectName = objectName,
            ContentType = contentType
        }, cts.Token);

        Console.WriteLine($"[SIGNED] URL:\n{signed.Url}\nExpira: {signed.ExpiresAt:u}");

        Console.WriteLine("[SIGNED] Enviando PUT direto para a URL assinada...");
        using var putResponse = await SignedUrlApiClient.PutFileAsync(signed.Url, localFile, contentType, cts.Token);
        Console.WriteLine($"[SIGNED] Upload finalizado. Status: {(int)putResponse.StatusCode} {putResponse.StatusCode}");
        putResponse.EnsureSuccessStatusCode();
    }

    async Task RunApiAsync()
    {
        Console.WriteLine("[API] Enviando arquivo para o endpoint /gcs/upload (multipart/form-data)...");
        using var resp = await ApiUploadHelper.UploadViaApiAsync(proxyApiBase, bucket, objectName, localFile, cts.Token);
        var body = await resp.Content.ReadAsStringAsync(cts.Token);
        Console.WriteLine($"[API] Upload finalizado. Status: {(int)resp.StatusCode} {resp.StatusCode}");
        Console.WriteLine($"[API] Corpo: {body}");
        resp.EnsureSuccessStatusCode();
    }

    switch (mode.ToLowerInvariant())
    {
        case "signed":
            await RunSignedAsync();
            break;
        case "api":
            await RunApiAsync();
            break;
        default:
            await RunSignedAsync();
            Console.WriteLine();
            await RunApiAsync();
            break;
    }
