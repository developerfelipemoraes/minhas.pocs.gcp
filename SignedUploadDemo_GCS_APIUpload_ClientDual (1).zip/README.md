# SignedUploadDemo (.NET 8)
Este pacote contém **dois componentes**:

1. **ProxySignedUrlApi** (Web API): recebe `{BucketName, ObjetName/ObjectName}`, chama uma **API geradora de URL assinada** (configurável) e **devolve a resposta** como veio.
2. **UploaderClient** (Console): chama a API acima para obter a URL assinada e, em seguida, faz **HTTP PUT** do arquivo local para a URL.

## Como usar
1. Edite `ProxySignedUrlApi/appsettings.json` e aponte `SigningApi.BaseUrl`/`EndpointPath` para sua API real de assinatura (ex.: GCS, S3, Azure Blob).
2. Rode a API Proxy:
   ```bash
   dotnet run --project ProxySignedUrlApi/ProxySignedUrlApi.csproj --urls http://localhost:5299
   ```
   Abra `http://localhost:5299/swagger` para testar.
3. Ajuste o caminho do arquivo em `UploaderClient/Program.cs` se necessário (`c:\temp\files\file0001.jpg`).
4. Rode o console:
   ```bash
   dotnet run --project UploaderClient/UploaderClient.csproj
   ```

## Observações
- `Content-Type` deve coincidir com o usado na geração da assinatura (para PUT).
- Se a resposta da assinatura exigir cabeçalhos adicionais, adicione-os no `HttpRequestMessage` antes do PUT.
- Upload por stream (`StreamContent`) para não carregar tudo na memória.

## Estrutura
Consulte os projetos para ver os arquivos e namespaces.


---

## (Novo) Assinatura direta no GCS (sem outra API)
A mesma Web API agora expõe `POST /gcs/signed-upload-url` que **gera a URL assinada V4 diretamente no GCS**.

**Requisitos de credencial:**
- Configure **ADC** ou `GOOGLE_APPLICATION_CREDENTIALS` apontando para um **Service Account JSON**.
- O service account precisa de permissões para assinar e fazer upload, por exemplo:
  - `roles/iam.serviceAccountTokenCreator` (se usando keyless/ADC sem arquivo JSON, para IAM SignBlob)
  - `roles/storage.objectCreator` (ou `roles/storage.admin` durante testes)

**Exemplo de chamada (via curl):**
```bash
curl -X POST "http://localhost:5299/gcs/signed-upload-url" ^
  -H "Content-Type: application/json" ^
  -d "{ \"BucketName\": \"filesmanager\", \"ObjetName\": \"upload/asdasdas.jpg\", \"ContentType\": \"image/jpeg\" }"
```

O `UploaderClient` pode continuar igual, ou você pode apontá-lo para `gcs/signed-upload-url` (ajustando o endpoint usado no `SignedUrlApiClient`).

**Importante:** O **Content-Type** incluído na assinatura deve ser o mesmo do PUT.


### Upload direto via API para o GCS
Novo endpoint: `POST /gcs/upload?bucket=filesmanager&objectName=upload/asdasdas.jpg`

Envie `multipart/form-data` com o campo **file**. Exemplo (PowerShell):

```powershell
Invoke-RestMethod -Method Post `
  -Uri "http://localhost:5299/gcs/upload?bucket=filesmanager&objectName=upload/asdasdas.jpg" `
  -Form @{ file = Get-Item "C:\temp\files\file0001.jpg" }

```

Ou via curl:

```bash
curl -X POST "http://localhost:5299/gcs/upload?bucket=filesmanager&objectName=upload/asdasdas.jpg" \

  -F "file=@C:/temp/files/file0001.jpg"

```

**Requisitos:** credencial ADC ou `GOOGLE_APPLICATION_CREDENTIALS` configurado na máquina/container que roda a API.



### Cliente com dois modos
O `UploaderClient` agora suporta:
- **Direto por URL assinada (PUT)**: `dotnet run --project UploaderClient/UploaderClient.csproj -- --mode=signed`
- **Upload via API** (`/gcs/upload` multipart): `dotnet run --project UploaderClient/UploaderClient.csproj -- --mode=api`
- **Ambos (padrão)**: sem argumentos ou `--mode=both`

Ajuste `bucket`, `objectName` e `localFile` em `UploaderClient/Program.cs` conforme seu cenário.
