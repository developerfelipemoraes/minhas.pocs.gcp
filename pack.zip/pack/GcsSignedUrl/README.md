# GcsSignedUrl

Biblioteca .NET (NuGet) para integrar com **Google Cloud Storage** com foco em:
- **Listagem de objetos** (por prefixo)
- **Metadados** (`GetObject`)
- **Geração de Signed URL (V4)** para **download**
- **Proxy de download por streaming** (sem carregar o arquivo em memória)
- **HttpInvoker** com **request/response** fortes para download por stream
- **DI Extension** `AddGcsSignedUrl` com suporte a **ADC/IAM** ou **JSON de Service Account**

Funciona com **todos os tipos de arquivos** (sem inspeção/conversão).

---

## Instalação

### Empacotar (local)

```bash
dotnet pack ./src/GcsSignedUrl.csproj -c Release
# gera bin/Release/GcsSignedUrl.<versão>.nupkg
```

### Publicar no NuGet.org

```bash
dotnet nuget push ./src/bin/Release/GcsSignedUrl.1.0.0.nupkg \
  --api-key <SEU_API_KEY> \
  --source https://api.nuget.org/v3/index.json
```

---

## Configuração

### `Program.cs` / Composition Root

```csharp
builder.Services.AddGcsSignedUrl(builder.Configuration, "GcsSignedUrl");
```

### `appsettings.json` (exemplo)

```json
{
  "GcsSignedUrl": {
    "Bucket": "filesmanager",
    "DefaultTtlMinutes": 10,

    // Opção 1: ADC/IAM (Workload Identity / Compute / Cloud Run / GKE)
    // Deixe ServiceAccountJson* como null e rode no ambiente com identidade de serviço.

    // Opção 2: JSON por arquivo
    "ServiceAccountJsonPath": "gcs-signer.json",

    // Opção 3: JSON em Base64 (tem precedência sobre o Path)
    "ServiceAccountJsonBase64": null,

    // (Opcional) impersonar outro Service Account via IAM
    "ImpersonateServiceAccount": null
  }
}
```

> **Permissões necessárias para assinar via IAM (sem chave privada):**  
> Conceda **`roles/iam.serviceAccountTokenCreator`** para a identidade efetiva no *service account* que assinará.

---

## Uso Rápido (Controller de exemplo)

```csharp
using GcsSignedUrl.Abstractions;
using GcsSignedUrl.Http;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/files")]
public class FilesController : ControllerBase
{
    private readonly IGcsStorageService _gcs;
    private readonly HttpInvoker _http;

    public FilesController(IGcsStorageService gcs, HttpInvoker http)
    {
        _gcs = gcs;
        _http = http;
    }

    [HttpGet("list")]
    public async Task<IActionResult> List([FromQuery] string? prefix = null, [FromQuery] int? pageSize = 100, CancellationToken ct = default)
    {
        var objs = await _gcs.ListAsync(prefix, pageSize, ct);
        return Ok(objs.Select(o => new { o.Name, o.Size, o.ContentType, o.Updated }));
    }

    [HttpGet("signed")]
    public async Task<IActionResult> Signed([FromQuery] string objectName, CancellationToken ct)
    {
        var url = await _gcs.CreateSignedDownloadUrlAsync(objectName, TimeSpan.FromMinutes(10), Path.GetFileName(objectName), ct);
        return Ok(new { url = url.ToString() });
    }

    [HttpGet("proxy")]
    public async Task<IActionResult> Proxy([FromQuery] string objectName, CancellationToken ct)
    {
        var meta = await _gcs.GetObjectMetadataAsync(objectName, ct);
        if (!string.IsNullOrEmpty(meta.ContentType))
            Response.Headers["Content-Type"] = meta.ContentType;
        Response.Headers["Content-Disposition"] = $"attachment; filename=\"{Path.GetFileName(objectName)}\"";

        var bytes = await _gcs.ProxyDownloadToStreamAsync(objectName, Response.Body, ct);
        Response.Headers["X-Bytes-Transferred"] = bytes.ToString();
        return new EmptyResult();
    }

    [HttpGet("signed-openread")]
    public async Task<IActionResult> SignedOpenRead([FromQuery] string objectName, CancellationToken ct)
    {
        await using var resp = await _gcs.OpenReadSignedAsync(objectName, TimeSpan.FromMinutes(10), ct);
        if (!string.IsNullOrEmpty(resp.ContentType))
            Response.Headers["Content-Type"] = resp.ContentType;
        Response.Headers["Content-Disposition"] = $"attachment; filename=\"{resp.FileName ?? Path.GetFileName(objectName)}\"";

        var buffer = new byte[128 * 1024];
        int read;
        long total = 0;
        while ((read = await resp.ContentStream.ReadAsync(buffer, 0, buffer.Length, ct)) > 0)
        {
            await Response.Body.WriteAsync(buffer.AsMemory(0, read), ct);
            total += read;
        }
        Response.Headers["X-Bytes-Transferred"] = total.ToString();
        return new EmptyResult();
    }
}
```

---

## API Pública

### `IGcsStorageService`

- `Task<IReadOnlyList<StorageObject>> ListAsync(string? prefix = null, int? pageSize = null, CancellationToken ct = default)`  
- `Task<Uri> CreateSignedDownloadUrlAsync(string objectName, TimeSpan? ttl = null, string? contentDispositionFileName = null, CancellationToken ct = default)`  
- `Task<long> ProxyDownloadToStreamAsync(string objectName, Stream destination, CancellationToken ct = default)`  
- `Task<StorageObject> GetObjectMetadataAsync(string objectName, CancellationToken ct = default)`  
- `Task<StreamDownloadResponse> OpenReadSignedAsync(string objectName, TimeSpan? ttl = null, CancellationToken ct = default)`

### `HttpInvoker`

- `Task<StreamDownloadResponse> GetStreamAsync(StreamDownloadRequest request, CancellationToken ct = default)`  
- `Task<long> DownloadToAsync(StreamDownloadRequest request, Stream destination, int bufferSize = 131072, CancellationToken ct = default)`

---

## Segurança e Boas Práticas

1. **Não exponha** JSON de service account em repositórios. Prefira **ADC/IAM** (Workload Identity) ou **variáveis de ambiente**.
2. Para assinar via IAM, garanta o papel **`roles/iam.serviceAccountTokenCreator`** no *service account* alvo.
3. Restrinja **prefixos**/nomes de objetos aceitos no backend (ex.: `uploads/`).
4. **TTL** de Signed URL: use o **mínimo necessário**.
5. Streaming com `ResponseHeadersRead`; evite carregar arquivos inteiros em memória.
6. Cuidado ao **logar** URLs assinadas; elas são credenciais temporárias.

---

## Licença

MIT (ou a sua de preferência).
