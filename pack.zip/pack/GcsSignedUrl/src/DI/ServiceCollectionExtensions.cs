using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using Google.Apis.Storage.v1;
using GcsSignedUrl.Abstractions;
using GcsSignedUrl.Http;
using GcsSignedUrl.Options;
using GcsSignedUrl.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace GcsSignedUrl.DI;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registra HttpInvoker, StorageClient, UrlSigner e IGcsStorageService.
    /// Suporta:
    /// - ADC/IAM (Workload Identity / Compute / Cloud Run / GKE)
    /// - JSON de Service Account via path ou Base64.
    /// - (Opcional) impersonação de Service Account (para StorageClient). Para UrlSigner, recomenda-se que a identidade final tenha permissão de assinar (IAM "Service Account Token Creator").
    /// </summary>
    public static IServiceCollection AddGcsSignedUrl(
        this IServiceCollection services,
        IConfiguration configuration,
        string sectionName = "GcsSignedUrl",
        Action<GcsOptions>? configure = null)
    {
        var options = new GcsOptions();
        configuration.GetSection(sectionName).Bind(options);
        configure?.Invoke(options);

        if (string.IsNullOrWhiteSpace(options.Bucket))
            throw new InvalidOperationException($"{sectionName}: 'Bucket' é obrigatório.");

        services.AddSingleton(options);

        // HttpClient para streaming (gzip/deflate/brotli)
        services.AddHttpClient("GcsSignedUrl.Http", c =>
        {
            // Não setamos Content-Type para permitir "todos os tipos de arquivos".
        }).ConfigurePrimaryHttpMessageHandler(() => new SocketsHttpHandler
        {
            AutomaticDecompression = System.Net.DecompressionMethods.All
        });

        // Construção de credenciais base (ADC ou Service Account JSON)
        services.AddSingleton(provider =>
        {
            GoogleCredential credential;

            var opts = provider.GetRequiredService<GcsOptions>();

            if (!string.IsNullOrWhiteSpace(opts.ServiceAccountJsonBase64))
            {
                var json = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(opts.ServiceAccountJsonBase64));
                credential = GoogleCredential.FromJson(json);
            }
            else if (!string.IsNullOrWhiteSpace(opts.ServiceAccountJsonPath))
            {
                credential = GoogleCredential.FromFile(opts.ServiceAccountJsonPath);
            }
            else
            {
                credential = GoogleCredential.GetApplicationDefault();
            }

            return credential;
        });

        // StorageClient (usando credencial base + escopos Storage)
        services.AddSingleton(provider =>
        {
            var cred = provider.GetRequiredService<GoogleCredential>();
            // Escopo FullControl para Storage vem do pacote Google.Apis.Storage.v1
            
            var scoped = cred.CreateScoped(StorageService.Scope.DevstorageFullControl);

            return StorageClient.Create(scoped);
        });

                // UrlSigner (usa IAM SignBlob quando possível)
        services.AddSingleton(provider =>
        {
            var baseCred = provider.GetRequiredService<GoogleCredential>();
            return UrlSigner.FromCredential(baseCred);
        });

        // HttpInvoker + Service
        services.AddSingleton<HttpInvoker>();

        services.AddSingleton<IGcsStorageService, GcsStorageService>();

        return services;
    }
}
