using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using GcsSignedUrl.Abstractions;
using GcsSignedUrl.Http;
using GcsSignedUrl.Options;
using System.Net.Http;

namespace GcsSignedUrl.Services;

public sealed class GcsStorageService : IGcsStorageService
{
    private readonly StorageClient _storage;
    private readonly UrlSigner _urlSigner;
    private readonly HttpInvoker _httpInvoker;
    private readonly GcsOptions _options;

    public GcsStorageService(
        StorageClient storage,
        UrlSigner urlSigner,
        HttpInvoker httpInvoker,
        GcsOptions options)
    {
        _storage = storage;
        _urlSigner = urlSigner;
        _httpInvoker = httpInvoker;
        _options = options;
    }

    public async Task<IReadOnlyList<Google.Apis.Storage.v1.Data.Object>> ListAsync(
        string? prefix = null,
        int? pageSize = null,
        CancellationToken cancellationToken = default)
    {
        var results = new List<Google.Apis.Storage.v1.Data.Object>();
        var asyncEnum = _storage.ListObjectsAsync(_options.Bucket, prefix);

        await foreach (var obj in asyncEnum.WithCancellation(cancellationToken))
        {
            results.Add(obj);
            if (pageSize.HasValue && results.Count >= pageSize.Value)
                break;
        }
        return results;
    }

    public async Task<Google.Apis.Storage.v1.Data.Object> GetObjectMetadataAsync(
        string objectName,
        CancellationToken cancellationToken = default)
    {
        return await _storage.GetObjectAsync(_options.Bucket, objectName, cancellationToken: cancellationToken);
    }
    public Task<Uri> CreateSignedDownloadUrlAsync(
        string objectName,
        TimeSpan? ttl = null,
        string? contentDispositionFileName = null,
        CancellationToken cancellationToken = default)
    {
        var duration = ttl ?? TimeSpan.FromMinutes(_options.DefaultTtlMinutes);

        var template = UrlSigner.RequestTemplate
            .FromBucket(_options.Bucket)
            .WithObjectName(objectName)
            .WithHttpMethod(HttpMethod.Get);

        if (!string.IsNullOrWhiteSpace(contentDispositionFileName))
        {
            var cd = $"attachment; filename=\"{Path.GetFileName(contentDispositionFileName)}\"";

            template = template.WithQueryParameters(new[]
            {
            new KeyValuePair<string, IEnumerable<string>>(
                "response-content-disposition",
                new[] { cd })
        });
        }

        var signedUrl = _urlSigner.Sign(
            template,
            UrlSigner.Options.FromDuration(duration));

        return Task.FromResult(new Uri(signedUrl));
    }

    public async Task<long> ProxyDownloadToStreamAsync(
        string objectName,
        Stream destination,
        CancellationToken cancellationToken = default)
    {
        long totalBytes = 0L;

        await using var temp = new CountingWriteStream(destination, onCount: c => totalBytes += c);

        await _storage.DownloadObjectAsync(
            bucket: _options.Bucket,
            objectName: objectName,
            destination: temp,
            cancellationToken: cancellationToken);

        await temp.FlushAsync(cancellationToken);
        return totalBytes;
    }

    public async Task<StreamDownloadResponse> OpenReadSignedAsync(
        string objectName,
        TimeSpan? ttl = null,
        CancellationToken cancellationToken = default)
    {
        var url = await CreateSignedDownloadUrlAsync(objectName, ttl, Path.GetFileName(objectName), cancellationToken);
        var req = new StreamDownloadRequest { Url = url };
        return await _httpInvoker.GetStreamAsync(req, cancellationToken);
    }

    /// <summary>
    /// Stream decorador que contabiliza bytes escritos.
    /// </summary>
    private sealed class CountingWriteStream : Stream
    {
        private readonly Stream _inner;
        private readonly Action<int> _onCount;

        public CountingWriteStream(Stream inner, Action<int> onCount)
        {
            _inner = inner;
            _onCount = onCount;
        }

        public override bool CanRead => _inner.CanRead;
        public override bool CanSeek => _inner.CanSeek;
        public override bool CanWrite => _inner.CanWrite;
        public override long Length => _inner.Length;
        public override long Position { get => _inner.Position; set => _inner.Position = value; }
        public override void Flush() => _inner.Flush();
        public override Task FlushAsync(CancellationToken cancellationToken) => _inner.FlushAsync(cancellationToken);
        public override int Read(byte[] buffer, int offset, int count) => _inner.Read(buffer, offset, count);
        public override long Seek(long offset, SeekOrigin origin) => _inner.Seek(offset, origin);
        public override void SetLength(long value) => _inner.SetLength(value);

        public override void Write(byte[] buffer, int offset, int count)
        {
            _inner.Write(buffer, offset, count);
            _onCount(count);
        }

        public override async Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
        {
            await _inner.WriteAsync(buffer.AsMemory(offset, count), cancellationToken);
            _onCount(count);
        }

        public override ValueTask WriteAsync(ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            _onCount(buffer.Length);
            return _inner.WriteAsync(buffer, cancellationToken);
        }
    }
}
