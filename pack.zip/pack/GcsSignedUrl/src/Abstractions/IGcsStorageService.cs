using GcsSignedUrl.Http;

namespace GcsSignedUrl.Abstractions;

public interface IGcsStorageService
{
    /// <summary>
    /// Lista objetos por prefixo (paginando no cliente, se pageSize informado).
    /// </summary>
    Task<IReadOnlyList<Google.Apis.Storage.v1.Data.Object>> ListAsync(
        string? prefix = null,
        int? pageSize = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Cria uma Signed URL (V4) para download (GET). TTL padrão vem de GcsOptions.
    /// </summary>
    Task<Uri> CreateSignedDownloadUrlAsync(
        string objectName,
        TimeSpan? ttl = null,
        string? contentDispositionFileName = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Faz proxy do download do objeto para um stream de saída (sem carregar em memória).
    /// Retorna o total de bytes transmitidos.
    /// </summary>
    Task<long> ProxyDownloadToStreamAsync(
        string objectName,
        Stream destination,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Retorna metadados do objeto (contentType, size, updated, custom metadata, etc.).
    /// </summary>
    Task<Google.Apis.Storage.v1.Data.Object> GetObjectMetadataAsync(
        string objectName,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Atalho: abre um stream de leitura via Signed URL (V4).
    /// O chamador deve descartar (await using) a resposta após o uso.
    /// </summary>
    Task<StreamDownloadResponse> OpenReadSignedAsync(
        string objectName,
        TimeSpan? ttl = null,
        CancellationToken cancellationToken = default);
}
