using System.Net.Http.Headers;

namespace GcsSignedUrl.Http;

public sealed class StreamDownloadRequest
{
    /// <summary>URL para download (por ex., Signed URL V4).</summary>
    public required Uri Url { get; init; }

    /// <summary>Headers adicionais (opcional).</summary>
    public IDictionary<string, string>? Headers { get; init; }

    /// <summary>Timeout da requisição (opcional). Usa HttpClient default se null.</summary>
    public TimeSpan? Timeout { get; init; }

    /// <summary>Faixa de bytes (HTTP Range) opcional. Ex.: "bytes=0-1048575".</summary>
    public string? RangeHeader { get; init; }

    /// <summary>Disposição para Content-Disposition no cliente final (apenas informativo neste nível).</summary>
    public string? SuggestedFileName { get; init; }
}
