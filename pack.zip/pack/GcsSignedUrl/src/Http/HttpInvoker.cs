using System.Net.Http.Headers;

namespace GcsSignedUrl.Http;

/// <summary>
/// Utilitário HTTP focado em downloads por streaming (ResponseHeadersRead).
/// </summary>
public sealed class HttpInvoker
{
    private readonly IHttpClientFactory _clientFactory;
    private const string ClientName = "GcsSignedUrl.Http";

    public HttpInvoker(IHttpClientFactory clientFactory)
        => _clientFactory = clientFactory;

    /// <summary>
    /// Abre uma resposta de streaming para a URL informada. 
    /// O chamador é responsável por copiar o conteúdo para um destino e descartar a resposta.
    /// </summary>
    public async Task<StreamDownloadResponse> GetStreamAsync(
        StreamDownloadRequest request,
        CancellationToken cancellationToken = default)
    {
        var client = _clientFactory.CreateClient(ClientName);
        if (request.Timeout is not null)
            client.Timeout = request.Timeout.Value;

        using var httpRequest = new HttpRequestMessage(HttpMethod.Get, request.Url);

        if (request.Headers is not null)
        {
            foreach (var kv in request.Headers)
            {
                httpRequest.Headers.TryAddWithoutValidation(kv.Key, kv.Value);
            }
        }

        if (!string.IsNullOrEmpty(request.RangeHeader))
        {
            httpRequest.Headers.Range = RangeHeaderValue.Parse(request.RangeHeader);
        }

        var response = await client.SendAsync(
            httpRequest,
            HttpCompletionOption.ResponseHeadersRead,
            cancellationToken);

        var stream = await response.Content.ReadAsStreamAsync(cancellationToken);

        string? fileName = null;
        if (response.Content.Headers.ContentDisposition is { } cd)
        {
            fileName = cd.FileNameStar ?? cd.FileName?.Trim('\"', '\'');
        }

        return new StreamDownloadResponse
        {
            StatusCode = response.StatusCode,
            ContentType = response.Content.Headers.ContentType?.ToString(),
            ContentLength = response.Content.Headers.ContentLength,
            FileName = fileName,
            ContentStream = stream
        };
    }

    /// <summary>
    /// Baixa por streaming para um destino (arquivo/pipe/etc), retornando bytes copiados.
    /// </summary>
    public async Task<long> DownloadToAsync(
        StreamDownloadRequest request,
        Stream destination,
        int bufferSize = 128 * 1024,
        CancellationToken cancellationToken = default)
    {
        await using var streamed = await GetStreamAsync(request, cancellationToken);

        var buffer = new byte[bufferSize];
        long total = 0;
        int read;
        while ((read = await streamed.ContentStream.ReadAsync(buffer.AsMemory(0, buffer.Length), cancellationToken)) > 0)
        {
            await destination.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
            total += read;
        }
        return total;
    }
}
