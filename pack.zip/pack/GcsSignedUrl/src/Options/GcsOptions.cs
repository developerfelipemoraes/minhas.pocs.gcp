namespace GcsSignedUrl.Options;

public sealed class GcsOptions
{
    /// <summary>Nome do bucket GCS.</summary>
    public string Bucket { get; set; } = default!;

    /// <summary>Caminho para o JSON do service account (opcional; use ADC/IAM se nulo).</summary>
    public string? ServiceAccountJsonPath { get; set; }

    /// <summary>JSON do service account em Base64 (opcional; tem precedência sobre o Path).</summary>
    public string? ServiceAccountJsonBase64 { get; set; }

    /// <summary>TTL padrão (em minutos) para Signed URLs.</summary>
    public int DefaultTtlMinutes { get; set; } = 10;

    /// <summary>
    /// (Opcional) Email do Service Account a ser impersonado via IAM.
    /// Requer que a credencial de origem tenha "Service Account Token Creator" no SA alvo.
    /// </summary>
    public string? ImpersonateServiceAccount { get; set; }
}
