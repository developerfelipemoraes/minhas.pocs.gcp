using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Aurovel.Gcs.Auth;
using Aurovel.Gcs.Configuration;
using Aurovel.Gcs.Services;

namespace Aurovel.Gcs.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddGcsInfrastructure(
            this IServiceCollection services,
            IConfiguration configuration,
            string sectionName = "Gcs")
        {
            services.AddOptions<GcsOptions>()
                    .Bind(configuration.GetSection(sectionName))
                    .Validate(opt => !string.IsNullOrWhiteSpace(opt.Bucket),
                              "Gcs:Bucket é obrigatório");

            services.AddHttpClient("GcsSignedUrlHttp");

            services.AddSingleton<GoogleCredential>(sp =>
            {
                var opt = sp.GetRequiredService<IOptions<GcsOptions>>().Value;
                return GcsAuthFactory.CreateGoogleCredential(opt);
            });

            services.AddSingleton<UrlSigner>(sp =>
            {
                var cred = sp.GetRequiredService<GoogleCredential>();
                return GcsAuthFactory.CreateUrlSigner(cred);
            });

            services.AddSingleton<StorageClient>(sp =>
            {
                var cred = sp.GetRequiredService<GoogleCredential>();
                return GcsAuthFactory.CreateStorageClient(cred);
            });

            services.AddScoped<IGcsFileService, GcsFileService>();

            return services;
        }
    }
}
