using System.Net;

namespace Aurovel.Gcs.Models
{
    public sealed class StreamDownloadResponse : IAsyncDisposable
    {
        /// <summary>Status HTTP da resposta.</summary>
        public required HttpStatusCode StatusCode { get; init; }

        /// <summary>Tipo de conteúdo (quando informado pelo servidor de origem).</summary>
        public string? ContentType { get; init; }

        /// <summary>Tamanho conhecido (Content-Length), se disponível.</summary>
        public long? ContentLength { get; init; }

        /// <summary>Nome de arquivo sugerido (quando o servidor envia Content-Disposition), se disponível.</summary>
        public string? FileName { get; init; }

        /// <summary>Stream bruto de conteúdo. Deve ser consumido e/ou copiado pelo chamador.</summary>
        public required Stream ContentStream { get; init; }

        /// <summary>Libera o stream subjacente.</summary>
        public ValueTask DisposeAsync()
        {
            ContentStream.Dispose();
            return ValueTask.CompletedTask;
        }
    }
}
