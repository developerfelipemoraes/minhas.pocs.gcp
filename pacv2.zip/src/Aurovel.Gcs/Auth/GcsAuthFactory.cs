using Google.Apis.Auth.OAuth2;
using Google.Apis.Storage.v1;
using Google.Cloud.Storage.V1;
using Aurovel.Gcs.Configuration;
using System.Text;

namespace Aurovel.Gcs.Auth
{
    public static class GcsAuthFactory
    {
        // Escopos para Storage + IAM
        private static readonly string[] Scopes = new[]
        {
            StorageService.Scope.DevstorageFullControl,
            "https://www.googleapis.com/auth/cloud-platform"
        };

        public static GoogleCredential CreateGoogleCredential(GcsOptions opt)
        {
            GoogleCredential cred;

            if (!string.IsNullOrWhiteSpace(opt.ServiceAccountJsonBase64))
            {
                var json = Encoding.UTF8.GetString(Convert.FromBase64String(opt.ServiceAccountJsonBase64));
                cred = GoogleCredential.FromJson(json);
            }
            else if (!string.IsNullOrWhiteSpace(opt.ServiceAccountJsonPath))
            {
                cred = GoogleCredential.FromFile(opt.ServiceAccountJsonPath);
            }
            else
            {
                cred = GoogleCredential.GetApplicationDefault();
            }

            // Impersonation (opcional)
            if (!string.IsNullOrWhiteSpace(opt.ImpersonateServiceAccount))
            {
                var impersonated = ImpersonatedCredential.Create(
                    cred,
                    opt.ImpersonateServiceAccount,
                    null,
                    Scopes,
                    TimeSpan.FromHours(1));

                cred = GoogleCredential.FromCredential(impersonated);
            }

            if (cred.IsCreateScopedRequired)
                cred = cred.CreateScoped(Scopes);

            return cred;
        }

        public static UrlSigner CreateUrlSigner(GoogleCredential cred)
        {
            if (cred.UnderlyingCredential is ServiceAccountCredential sac && sac.HasPrivateKey)
                return UrlSigner.FromServiceAccountCredential(sac);

            return UrlSigner.FromCredential(cred);
        }

        public static StorageClient CreateStorageClient(GoogleCredential cred)
            => new StorageClientBuilder { Credential = cred }.Build();
    }
}
