using Microsoft.AspNetCore.Http;

namespace Aurovel.Gcs.Services
{
    public interface IGcsFileService
    {
        // URLs assinadas
        Task<Uri> CreateSignedDownloadUrlAsync(string objectName, TimeSpan ttl, CancellationToken ct = default);
        Task<Uri> CreateSignedResumableUploadUrlAsync(string objectName, TimeSpan ttl, CancellationToken ct = default);

        // Stream (proxy) do arquivo para uma HttpResponse
        Task ProxyDownloadAsync(HttpResponse httpResponse, string objectName, string? downloadFileName = null, CancellationToken ct = default);

        // Abrir stream via Signed URL (sem carregar em memória)
        Task<Aurovel.Gcs.Models.StreamDownloadResponse> OpenSignedDownloadStreamAsync(string objectName, TimeSpan? ttl = null, CancellationToken ct = default);

        // Utilitários
        IAsyncEnumerable<string> ListAsync(string? prefix = null, int? limit = null, CancellationToken ct = default);
    }
}
