using Google.Cloud.Storage.V1;
using Microsoft.AspNetCore.Http;
using Aurovel.Gcs.Configuration;
using Aurovel.Gcs.Models;
using System.Net.Http.Headers;
using System.IO;

namespace Aurovel.Gcs.Services
{
    public sealed class GcsFileService : IGcsFileService
    {
        private readonly string _bucket;
        private readonly int _defaultTtlMinutes;
        private readonly UrlSigner _signer;
        private readonly StorageClient _storage;
        private readonly IHttpClientFactory _httpClientFactory;

        public GcsFileService(
            Microsoft.Extensions.Options.IOptions<GcsOptions> opt,
            UrlSigner signer,
            StorageClient storage,
            IHttpClientFactory httpClientFactory)
        {
            var cfg = opt.Value;
            _bucket = cfg.Bucket;
            _defaultTtlMinutes = cfg.DefaultTtlMinutes;
            _signer = signer;
            _storage = storage;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<Uri> CreateSignedDownloadUrlAsync(string objectName, TimeSpan ttl, CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(objectName))
                throw new ArgumentException("objectName requerido.", nameof(objectName));

            var template = UrlSigner.RequestTemplate
                .FromBucket(_bucket)
                .WithObjectName(objectName)
                .WithHttpMethod(HttpMethod.Get);

            var url = await _signer.SignAsync(template, UrlSigner.Options.FromDuration(ttl), ct);
            return new Uri(url);
        }

        public async Task<Uri> CreateSignedResumableUploadUrlAsync(string objectName, TimeSpan ttl, CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(objectName))
                throw new ArgumentException("objectName requerido.", nameof(objectName));

            var template = UrlSigner.RequestTemplate
                .FromBucket(_bucket)
                .WithObjectName(objectName)
                .WithHttpMethod(UrlSigner.ResumableHttpMethod);

            var url = await _signer.SignAsync(template, UrlSigner.Options.FromDuration(ttl), ct);
            return new Uri(url);
        }

        public async Task<StreamDownloadResponse> OpenSignedDownloadStreamAsync(
            string objectName, TimeSpan? ttl = null, CancellationToken ct = default)
        {
            var effectiveTtl = ttl ?? TimeSpan.FromMinutes(_defaultTtlMinutes);
            var url = await CreateSignedDownloadUrlAsync(objectName, effectiveTtl, ct);

            var http = _httpClientFactory.CreateClient("GcsSignedUrlHttp");
            var req = new HttpRequestMessage(HttpMethod.Get, url);
            var resp = await http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);

            var stream = await resp.Content.ReadAsStreamAsync(ct);

            string? contentType = resp.Content.Headers.ContentType?.ToString();
            long? contentLength = resp.Content.Headers.ContentLength;
            string? fileName = null;

            var cd = resp.Content.Headers.ContentDisposition;
            if (cd == null && resp.Content.Headers.TryGetValues("Content-Disposition", out var values))
            {
                if (ContentDispositionHeaderValue.TryParse(values.FirstOrDefault(), out var parsed))
                    cd = parsed;
            }
            if (cd != null)
                fileName = cd.FileNameStar ?? cd.FileName?.Trim('"');

            return new StreamDownloadResponse
            {
                StatusCode = resp.StatusCode,
                ContentType = contentType,
                ContentLength = contentLength,
                FileName = fileName ?? Path.GetFileName(objectName),
                ContentStream = stream
            };
        }

        public async Task ProxyDownloadAsync(HttpResponse response, string objectName, string? downloadFileName = null, CancellationToken ct = default)
        {
            if (string.IsNullOrWhiteSpace(objectName))
                throw new ArgumentException("objectName requerido.", nameof(objectName));

            var obj = await _storage.GetObjectAsync(_bucket, objectName, cancellationToken: ct);

            response.Headers["Content-Type"] = obj.ContentType ?? "application/octet-stream";
            var fileName = string.IsNullOrWhiteSpace(downloadFileName) ? Path.GetFileName(objectName) : downloadFileName;
            response.Headers["Content-Disposition"] = $"attachment; filename="{fileName}"";

            await _storage.DownloadObjectAsync(_bucket, objectName, response.Body, cancellationToken: ct);
        }

        public async IAsyncEnumerable<string> ListAsync(string? prefix = null, int? limit = null, [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
        {
            int count = 0;
            foreach (var obj in _storage.ListObjects(_bucket, prefix))
            {
                ct.ThrowIfCancellationRequested();
                yield return obj.Name;
                if (limit.HasValue && ++count >= limit.Value) yield break;
                await Task.Yield();
            }
        }
    }
}
