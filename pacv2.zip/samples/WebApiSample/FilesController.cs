using Microsoft.AspNetCore.Mvc;
using Aurovel.Gcs.Services;

namespace WebApiSample.Controllers;

[ApiController]
[Route("api/files")]
public class FilesController : ControllerBase
{
    private readonly IGcsFileService _gcs;
    public FilesController(IGcsFileService gcs) => _gcs = gcs;

    [HttpGet("signed-download")]
    public async Task<IActionResult> SignedDownload([FromQuery] string objectName, [FromQuery] int ttlMinutes = 10)
    {
        if (string.IsNullOrWhiteSpace(objectName)) return BadRequest("objectName requerido.");
        var url = await _gcs.CreateSignedDownloadUrlAsync(objectName, TimeSpan.FromMinutes(ttlMinutes));
        return Ok(new { url = url.ToString(), expiresAtUtc = DateTimeOffset.UtcNow.AddMinutes(ttlMinutes) });
    }

    [HttpGet("proxy")]
    public async Task<IActionResult> Proxy([FromQuery] string objectName)
    {
        if (string.IsNullOrWhiteSpace(objectName)) return BadRequest("objectName requerido.");
        await _gcs.ProxyDownloadAsync(Response, objectName);
        return new EmptyResult();
    }

    [HttpGet("list")]
    public async Task<IActionResult> List([FromQuery] string? prefix = "uploads/", [FromQuery] int pageSize = 50)
    {
        var results = new List<string>();
        await foreach (var name in _gcs.ListAsync(prefix, pageSize))
            results.Add(name);
        return Ok(results);
    }
}
