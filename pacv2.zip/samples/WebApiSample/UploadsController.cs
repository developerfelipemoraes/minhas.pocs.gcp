using Microsoft.AspNetCore.Mvc;
using Aurovel.Gcs.Services;

namespace WebApiSample.Controllers;

[ApiController]
[Route("api/uploads")]
public class UploadsController : ControllerBase
{
    private readonly IGcsFileService _gcs;
    public UploadsController(IGcsFileService gcs) => _gcs = gcs;

    [HttpPost("resumable")]
    public async Task<IActionResult> CreateResumable([FromQuery] string objectName, [FromQuery] int ttlMinutes = 300)
    {
        if (string.IsNullOrWhiteSpace(objectName)) return BadRequest("objectName requerido.");
        var url = await _gcs.CreateSignedResumableUploadUrlAsync(objectName, TimeSpan.FromMinutes(ttlMinutes));
        return Ok(new { url = url.ToString(), expiresAtUtc = DateTimeOffset.UtcNow.AddMinutes(ttlMinutes) });
    }
}
