# Aurovel.Gcs

Biblioteca para Google Cloud Storage: geração de Signed URLs (download/upload resumable), proxy de streaming direto do bucket e DI completo com múltiplas fontes de credencial (arquivo, JSON Base64, ADC, impersonation).

## Instalação

No seu projeto Web API (.NET 8):

```bash
dotnet add package Aurovel.Gcs
```

Ou, localmente: abra `src/Aurovel.Gcs/Aurovel.Gcs.csproj` e faça `dotnet pack` para gerar o `.nupkg`.

## Configuração (`appsettings.json`)

```json
{
  "Gcs": {
    "Bucket": "filesmanager",
    "DefaultTtlMinutes": 10,

    // Um dos dois (Base64 tem precedência):
    "ServiceAccountJsonBase64": null,
    "ServiceAccountJsonPath": "gcs-signer.json",

    // Opcional (impersonation):
    "ImpersonateServiceAccount": null
  }
}
```

Você também pode usar variáveis de ambiente (ex.: `Gcs__Bucket`, `Gcs__ServiceAccountJsonBase64`, etc.).

## Program.cs

```csharp
using Aurovel.Gcs.Extensions;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();

// Registra GCS infra lendo a seção "Gcs"
builder.Services.AddGcsInfrastructure(builder.Configuration, "Gcs");

var app = builder.Build();
app.MapControllers();
app.Run();
```

## Uso básico nos Controllers

```csharp
using Microsoft.AspNetCore.Mvc;
using Aurovel.Gcs.Services;
using Aurovel.Gcs.Models;

[ApiController]
[Route("api/files")]
public class FilesController : ControllerBase
{
    private readonly IGcsFileService _gcs;
    public FilesController(IGcsFileService gcs) => _gcs = gcs;

    [HttpGet("signed-download")]
    public async Task<IActionResult> SignedDownload([FromQuery] string objectName, [FromQuery] int ttlMinutes = 10)
    {
        var url = await _gcs.CreateSignedDownloadUrlAsync(objectName, TimeSpan.FromMinutes(ttlMinutes));
        return Ok(new { url = url.ToString(), expiresAtUtc = DateTimeOffset.UtcNow.AddMinutes(ttlMinutes) });
    }

    [HttpGet("proxy")]
    public async Task<IActionResult> Proxy([FromQuery] string objectName)
    {
        await _gcs.ProxyDownloadAsync(Response, objectName);
        return new EmptyResult();
    }
}

[ApiController]
[Route("api/uploads")]
public class UploadsController : ControllerBase
{
    private readonly IGcsFileService _gcs;
    public UploadsController(IGcsFileService gcs) => _gcs = gcs;

    [HttpPost]
    public async Task<IActionResult> CreateResumable([FromQuery] string objectName)
    {
        var url = await _gcs.CreateSignedResumableUploadUrlAsync(objectName, TimeSpan.FromHours(5));
        return Ok(new { url = url.ToString() });
    }
}
```

## API da Service

- `CreateSignedDownloadUrlAsync(objectName, ttl)`
- `CreateSignedResumableUploadUrlAsync(objectName, ttl)`
- `OpenSignedDownloadStreamAsync(objectName, ttl?)` → retorna `StreamDownloadResponse` com `ContentStream`
- `ProxyDownloadAsync(HttpResponse, objectName, fileName?)` → baixa direto para o response
- `ListAsync(prefix?, limit?)` → iterador de nomes de objetos

## Notas

- Quando o `GoogleCredential` contém chave privada (Service Account Key), o `UrlSigner` assina **localmente**. Caso contrário, usa **IAM SignBlob**.
- `ImpersonateServiceAccount` exige que a credencial de origem tenha o papel **Service Account Token Creator** no SA alvo.
