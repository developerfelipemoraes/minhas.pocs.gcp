// See https://aka.ms/new-console-template for more information
using PocGcsConsole;

Console.WriteLine("=============Poc Google Cloud Storage ===========");
Console.WriteLine("=============Menu de Opções =====================");
Console.WriteLine("1) Upload Url Assinada  ==============");
Console.WriteLine("2) Upload via Stream   ==============");
Console.WriteLine("3) Downlaod via Url Assinada  ==============");
Console.WriteLine("4) Downlaod via Url Stream ==============");
Console.WriteLine("5) Sair ==============");
Console.Write("Digite a opção desejada: ");
var opcaoMenu = Console.ReadLine();

switch (opcaoMenu)
{
    case "1":
        await PocGcS.UploadUrlAssinada();
        break;
    case "2":
        await PocGcS.UploadViaStream(); // TODO
        break;
    case "3":
        await PocGcS.DownloadUrlAssinada();
        break;
    case "4":
        await PocGcS.DownloadViaStream(); // TODO
        break;
    case "5":
        Console.WriteLine("Saindo...");
        break;
    default:
        Console.WriteLine("Opção inválida. Tente novamente.");
        break;
}