using PocGcsConsole.Models;
using PocGcsConsole.Services;
using System.Diagnostics;

namespace PocGcsConsole;

public static class PocGcS
{
    private static readonly string BaseUrl =
        Environment.GetEnvironmentVariable("STORAGE_API_BASEURL") ?? "https://localhost:7185/";

    private static readonly StorageApiClient ApiClient = new(new HttpClient
    {
        Timeout = TimeSpan.FromMinutes(10)
    }, BaseUrl);

    public static async Task UploadUrlAssinada()
    {
        Console.Write("BucketName: ");
        var bucketName = Console.ReadLine()!.Trim();

        Console.Write("Objeto no bucket (ex: uploads/meu-arquivo.jpg): ");
        var objectName = Console.ReadLine()!.Trim();

        Console.Write("Caminho do arquivo local (ex: C:/temp/files/file0001.jpg): ");
        var localPath = Console.ReadLine()!.Trim();

        Console.Write("Content-Type do arquivo (ex: image/jpeg): ");
        var contentType = Console.ReadLine()!.Trim();

        Console.Write("Duração da URL (minutos): ");
        var minutesStr = Console.ReadLine()!.Trim();
        if (!int.TryParse(minutesStr, out var minutes))
        {
            Console.WriteLine("Valor inválido. Usando 15 minutos por padrão.");
            minutes = 15;
        }

        var req = new UploadSignedUrlRequest
        {
            BucketName = bucketName,
            ObjectName = objectName,
            TimeDurationSeconds = minutes * 60,
            ContentTypeFile = contentType
        };

        var swTotal = Stopwatch.StartNew();

        Console.WriteLine("Solicitando URL assinada de upload à API...");
        var swApi = Stopwatch.StartNew();
        var signed = await ApiClient.GetUploadSignedUrlAsync(req);
        swApi.Stop();

        Console.WriteLine($"URL recebida. Expira em: {signed.ExpiresAt:o}");
        Console.WriteLine("Enviando arquivo diretamente ao GCS via URL assinada (HTTP PUT)...");

        var swTransfer = Stopwatch.StartNew();
        await SignedUrlTransfer.UploadWithSignedUrlAsync(signed.Url!, localPath, contentType);
        swTransfer.Stop();

        swTotal.Stop();

        var fileBytes = new FileInfo(localPath).Length;
        var fileMb = fileBytes / (1024.0 * 1024.0);
        var upSpeed = fileMb / Math.Max(0.000001, swTransfer.Elapsed.TotalSeconds);

        Console.WriteLine("==== MÉTRICAS DE UPLOAD ====");
        Console.WriteLine($"Tamanho do arquivo: {fileMb:F2} MB");
        Console.WriteLine($"Tempo API (gerar URL): {swApi.Elapsed.TotalSeconds:F3} s");
        Console.WriteLine($"Tempo transferência (PUT): {swTransfer.Elapsed.TotalSeconds:F3} s");
        Console.WriteLine($"Tempo TOTAL (API + PUT): {swTotal.Elapsed.TotalSeconds:F3} s");
        Console.WriteLine($"Throughput médio: {upSpeed:F2} MB/s");
        Console.WriteLine("============================");

        Console.WriteLine("Upload concluído com sucesso!");
        Console.WriteLine($"Bucket: {bucketName}");
        Console.WriteLine($"Objeto: {objectName}");
    }

    public static async Task DownloadUrlAssinada()
    {
        Console.Write("BucketName: ");
        var bucketName = Console.ReadLine()!.Trim();

        Console.Write("Objeto no bucket (ex: uploads/meu-arquivo.jpg): ");
        var objectName = Console.ReadLine()!.Trim();

        Console.Write("Destino local (ex: C:/temp/files/baixado.jpg): ");
        var localPath = Console.ReadLine()!.Trim();

        Console.Write("Duração da URL (minutos): ");
        var minutesStr = Console.ReadLine()!.Trim();
        if (!int.TryParse(minutesStr, out var minutes))
        {
            Console.WriteLine("Valor inválido. Usando 15 minutos por padrão.");
            minutes = 15;
        }

        var req = new DownloadSignedUrlRequest
        {
            BucketName = bucketName,
            ObjectName = objectName,
            TimeDurationSeconds = minutes * 60
        };

        var swTotal = Stopwatch.StartNew();

        Console.WriteLine("Solicitando URL assinada de download à API...");
        var swApi = Stopwatch.StartNew();
        var signed = await ApiClient.GetDownloadSignedUrlAsync(req);
        swApi.Stop();

        Console.WriteLine($"URL recebida. Expira em: {signed.ExpiresAt:o}");
        Console.WriteLine("Baixando arquivo diretamente do GCS via URL assinada (HTTP GET)...");

        var swTransfer = Stopwatch.StartNew();
        await SignedUrlTransfer.DownloadWithSignedUrlAsync(signed.Url!, localPath);
        swTransfer.Stop();

        swTotal.Stop();

        var fileBytes = new FileInfo(localPath).Length;
        var fileMb = fileBytes / (1024.0 * 1024.0);
        var downSpeed = fileMb / Math.Max(0.000001, swTransfer.Elapsed.TotalSeconds);

        Console.WriteLine("==== MÉTRICAS DE DOWNLOAD ====");
        Console.WriteLine($"Tamanho do arquivo: {fileMb:F2} MB");
        Console.WriteLine($"Tempo API (gerar URL): {swApi.Elapsed.TotalSeconds:F3} s");
        Console.WriteLine($"Tempo transferência (GET): {swTransfer.Elapsed.TotalSeconds:F3} s");
        Console.WriteLine($"Tempo TOTAL (API + GET): {swTotal.Elapsed.TotalSeconds:F3} s");
        Console.WriteLine($"Throughput médio: {downSpeed:F2} MB/s");
        Console.WriteLine("================================");

        Console.WriteLine("Download concluído com sucesso!");
        Console.WriteLine($"Arquivo salvo em: {localPath}");
    }

    public static Task UploadViaStream()
    {
        Console.WriteLine("UploadViaStream ainda não implementado.");
        return Task.CompletedTask;
    }

    public static Task DownloadViaStream()
    {
        Console.WriteLine("DownloadViaStream ainda não implementado.");
        return Task.CompletedTask;
    }
}