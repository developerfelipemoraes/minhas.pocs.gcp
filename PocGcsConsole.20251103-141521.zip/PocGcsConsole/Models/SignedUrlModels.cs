namespace PocGcsConsole.Models;

public sealed class UploadSignedUrlRequest
{
    public string BucketName { get; set; } = default!;
    public string ObjectName { get; set; } = default!;
    public int TimeDurationSeconds { get; set; }
    public string ContentTypeFile { get; set; } = default!;
}

public sealed class DownloadSignedUrlRequest
{
    public string BucketName { get; set; } = default!;
    public string ObjectName { get; set; } = default!;
    public int TimeDurationSeconds { get; set; }
}

public sealed class SignedUrlResponse
{
    public string? Url { get; set; }
    public string? Method { get; set; }
    public DateTimeOffset ExpiresAt { get; set; }
    public string? ObjectName { get; set; }
    public string? ContentType { get; set; }
}