# PocGcsConsole

Console .NET 8 para consumir sua API de URL assinada (GCS) e realizar upload/download direto com métricas de tempo e throughput.