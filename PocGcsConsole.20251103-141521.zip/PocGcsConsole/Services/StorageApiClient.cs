using System.Net.Http.Json;
using PocGcsConsole.Models;

namespace PocGcsConsole.Services;

public sealed class StorageApiClient
{
    private readonly HttpClient _http;
    private readonly string _baseAddress;
    private readonly string _uploadSignedUrlPath;
    private readonly string _downloadSignedUrlPath;

    public StorageApiClient(HttpClient http, string baseAddress,
        string uploadSignedUrlPath = "api/storage/signed-url/upload",
        string downloadSignedUrlPath = "api/storage/signed-url/download")
    {
        _http = http;
        _baseAddress = baseAddress.TrimEnd('/') + "/";
        _uploadSignedUrlPath = uploadSignedUrlPath.TrimStart('/');
        _downloadSignedUrlPath = downloadSignedUrlPath.TrimStart('/');
        _http.BaseAddress = new Uri(_baseAddress);
    }

    public async Task<SignedUrlResponse> GetUploadSignedUrlAsync(UploadSignedUrlRequest req, CancellationToken ct = default)
    {
        using var resp = await _http.PostAsJsonAsync(_uploadSignedUrlPath, req, ct);
        resp.EnsureSuccessStatusCode();
        var data = await resp.Content.ReadFromJsonAsync<SignedUrlResponse>(cancellationToken: ct);
        if (data is null || string.IsNullOrWhiteSpace(data.Url))
            throw new InvalidOperationException("Resposta da API inválida. 'Url' não informada.");
        return data;
    }

    public async Task<SignedUrlResponse> GetDownloadSignedUrlAsync(DownloadSignedUrlRequest req, CancellationToken ct = default)
    {
        using var resp = await _http.PostAsJsonAsync(_downloadSignedUrlPath, req, ct);
        resp.EnsureSuccessStatusCode();
        var data = await resp.Content.ReadFromJsonAsync<SignedUrlResponse>(cancellationToken: ct);
        if (data is null || string.IsNullOrWhiteSpace(data.Url))
            throw new InvalidOperationException("Resposta da API inválida. 'Url' não informada.");
        return data;
    }
}