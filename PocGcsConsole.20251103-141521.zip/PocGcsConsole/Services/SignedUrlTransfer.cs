using System.Net.Http.Headers;

namespace PocGcsConsole.Services;

public static class SignedUrlTransfer
{
    public static async Task UploadWithSignedUrlAsync(string signedUrl, string filePath, string contentType, CancellationToken ct = default)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException("Arquivo local não encontrado.", filePath);

        using var fileStream = File.OpenRead(filePath);
        using var content = new StreamContent(fileStream);
        content.Headers.ContentType = new MediaTypeHeaderValue(contentType);

        using var msg = new HttpRequestMessage(HttpMethod.Put, signedUrl) { Content = content };
        using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };

        var resp = await http.SendAsync(msg, HttpCompletionOption.ResponseHeadersRead, ct);
        resp.EnsureSuccessStatusCode();
    }

    public static async Task DownloadWithSignedUrlAsync(string signedUrl, string destinationPath, CancellationToken ct = default)
    {
        var dir = Path.GetDirectoryName(destinationPath);
        if (!string.IsNullOrWhiteSpace(dir) && !Directory.Exists(dir))
            Directory.CreateDirectory(dir!);

        using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };
        using var resp = await http.GetAsync(signedUrl, HttpCompletionOption.ResponseHeadersRead, ct);
        resp.EnsureSuccessStatusCode();

        await using var fs = File.Create(destinationPath);
        await resp.Content.CopyToAsync(fs, ct);
    }
}